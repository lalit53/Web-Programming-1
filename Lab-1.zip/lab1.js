const questionOne = function questionOne(arr) {
    // Implement question 1 here
    var soln=0;
        i=arr.length;
    while(i--){
        soln += Math.pow(arr[i],2)
    }
    return soln;
}

const questionTwo = function questionTwo(num) { 
    // Implement question 2 here
    if (num<0){
        return 0;
    }
    if (num==1 || num==2){
        return 1;
    }
    else{var i=0;
        var j=1;
        var m=1;
        while(m<num){
            var a=i+j;
            i=j;
            j=a;
            m+=1;
        }  
        return a; 


    }
}

const questionThree = function questionThree(text) {
    // Implement question 3 here 

    var vowel=0;
    var list= 'aeiouAEIOU';
    for(var i=0; i<text.length;i++){
        if(list.indexOf(text[i])!== -1)
        vowel++;
    }
    return vowel;
}

const questionFour = function questionFour(num) {
    // Implement question 4 here
    
    function fact(num){
        if(num<0){
            return NaN;
        }
        else if (num==0){
            return 1;
        }
        else {
            return (num*fact(num-1));
        }
    }
   return fact(num);
}

module.exports = {
    firstName: "Lalit", 
    lastName: "Kargutkar", 
    studentId: "10434413",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};