const animals = require("./animals");
const connection = require("./mongoConnection")

const main = async () => {
  const sasha = await animals.create("Sasha", "Dog");
    console.log(sasha);
  
    const sasha1 = await animals.getAll();
    console.log(sasha1);

  
  
  const lucy = await animals.create("Lucy", "Dog");
    console.log(lucy);


    const lucy1 = await animals.getAll();
    console.log(lucy1);

  const duke = await animals.create("Duke", "Walrus");
    console.log(duke);

  const bubba = await animals. rename("5c776424617f0185b0d79b83", "Sashita");
    console.log(bubba);

  
    const removeBlubBlub = await animals.remove("5c776424617f0185b0d79b84");
    console.log(removeBlubBlub);

    
    const lucy2 = await animals.getAll();
    console.log(lucy2);

    


  

const db = await connection();
  await db.serverConfig.close();
}

main().catch(error => {
  console.log(error);
})
  