const mongoCollections = require("./mongoCollections");
const animals = mongoCollections.animals;

module.exports = {

  async get(id) {
    const ObjectId = require('mongodb').ObjectID; 
    if (!id) throw "You must provide an id to search for";

    const animalCollection = await animals();
    const animal1 = await animalCollection.findOne( {_id: ObjectId(id)});
    if (animal1 === null) throw "No animal with that id";

    return animal1;
  },

  async getAll() {
    const animalCollection = await animals();

    const animalo = await animalCollection.find({}).toArray();

    return animalo
    ;
    
  },

  async create(name, animalType) {
    if (!name){
    throw "You must provide a name for your animal";
    }

    else if (!animalType){
      throw "You must provide an array of breeds";
    }

    else if(typeof name!=='string') {
      throw "name should be in words!"
    } 
    

    else if(typeof animalType!=='string') {
      throw "animal Type should be in words!"
    }

    const animalCollection = await animals();

    let newanimal = {
      name: name,
      animalType: animalType
    };

    const insertInfo = await animalCollection.insertOne(newanimal);
    if (insertInfo.insertedCount === 0) throw "Could not add animal";

    const newId = insertInfo.insertedId;

    const animal = await this.get(newId);
    return animal;
  },
  async remove(id) {
    const ObjectId = require('mongodb').ObjectID;
    if (!id) throw "You must provide an id to search for";

    const animalCollection = await animals();
    const a = await this.get(id)
    const deletionInfo = await animalCollection.removeOne({ _id: ObjectId(id) });


    

    if (deletionInfo.deletedCount === 0) {
      throw `Could not delete animal with id of ${id}`;
    }
      return a;
      
  },
 async rename(id, newName) {
  const ObjectId = require('mongodb').ObjectID;
    if (!id) throw "You must provide an id to search for";

    if (!newName) throw "You must provide a new name for your animal";

    const animalCollection = await animals();
    const animal=await this.get(id);
    const updatedAnimal = { $set: {
            name: newName,
      animalType: animal.animalType
    }
    };

    const updatedInfo = await animalCollection.updateOne({ _id: ObjectId(id) }, updatedAnimal);
    if (updatedInfo.modifiedCount === 0) {
      throw "could not update animal";
    }

    return await this.get(id);
  },

firstName:"Lalit",
lastName:"Kargutkar",
studendId: "10434413"

};
   


