async function getPeople(){
    // const data=[];
    const axios=require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
    return data; // this will be the array of people
  }

  async function getwork(){
    // const data=[];
    const axios=require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/61d560338443ba2a01cde3ad0cac6492/raw/8ea1be9d6adebd4bfd6cf4cc6b02ad8c5b1ca751/work.json');
    return data; // this will be the array of people
  }

  async function whereDoTheyWork(firstName, lastName){
    const workdata = await getwork()
    const peopledata = await getPeople()
    
    if(typeof firstName === 'undefined'){
        throw `Enter first name`
    }

    else if(typeof firstName !== 'string' || !(firstName)){
        throw `Enter first name`
    } 

    else if(typeof lastName === 'undefined'){
        throw `Enter last name`
    }

    else if(typeof lastName !== 'string' || !(lastName)){
        throw `Enter last name`
    }


    for(i=0 ; i<500; i++){
        if(firstName === peopledata[i].firstName && lastName === peopledata[i].lastName){
            var y = peopledata[i].ssn
            console.log(peopledata[i].firstName + " " + peopledata[i].lastName)
            break;
        }
        if(i===499){
            console.log(firstName+ " " + lastName +" not found") 
        }
    }

    for(j=0; j<500; j++){
        if(y===workdata[j].ssn){
            console.log(workdata[j].jobTitle+" at "+ workdata[j].company + ". " + workdata[j].willBeFired)
        }
       
    }
    

  }

  async function findTheHacker(ip){
    const peopledata = await getPeople()
    const workdata = await getwork()

    // if(block < 0 && block >256) {
    //     throw `Invalid I.P address`
    // }

    for(i=0; i<500; i++){
        if(ip === workdata[i].ip){
            var x = workdata[i].ssn
            break
        }
        if(i===499){
            console.log("Name not found")
        }

    }
    for(j=0; j<500; j++){
        if(x === peopledata[j].ssn){
        console.log(peopledata[j].firstName+" "+ peopledata[j].lastName+" is the hacker.")
        }
    }
}

module.exports={
firstName:"Lalit",
lastName:"Kargutkar",
studendId: "10434413",
whereDoTheyWork,
findTheHacker};

