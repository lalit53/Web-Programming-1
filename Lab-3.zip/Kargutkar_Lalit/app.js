const people = require("./people");
const weather= require("./weather");
const work=require("./work");

async function main(){
    try{
        const a = await people.getPersonById(4)
    }catch(e){
        console.log (e);
    }

    try{
        const b = await people.lexIndex(2)
    }catch(e){
        console.log(e); 
    }

   try{
       const c = await people.firstNameMetrics();
   }catch(e){
       console.log(e);
   }

   try{
       const d = await weather.shouldTheyGoOutside("Calli", "Ondrasek")
   }catch(e){
       console.log(e);
   }

   try{
    const f = await work. whereDoTheyWork("Demetra", "Durrand")
}catch(e){
    console.log(e);
}

try{
    const f = await work.findTheHacker("79.222.167.180")
}catch(e){
    console.log(e);
}
}

main();