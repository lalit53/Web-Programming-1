async function getPeople(){
    // const data=[];
    const axios=require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
    return data; // this will be the array of people
  }

  async function getWeather(){
    // const data=[];
    const axios=require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73https://gist.githubusercontent.com/robherley/1b950dc4fbe9d5209de4a0be7d503801/raw/eee79bf85970b8b2b80771a66182aa488f1d7f29/weather.json');
    return data; // this will be the array of people
  }

async function shouldTheyGoOutside(firstName, lastName){
    const weatherdata = await getWeather()
    const peopledata = await getPeople()
    if(typeof firstName === 'undefined'){
        throw `Enter first name`
    }

    else if(typeof firstName !== 'string' || !(firstName)){
        throw `Enter first name`
    } 

    else if(typeof lastName === 'undefined'){
        throw `Enter last name`
    }

    else if(typeof lastName !== 'string' || !(lastName)){
        throw `Enter last name`
    }

    for(i=0 ; i<500; i++){
        if(firstName === peopledata[i].firstName && lastName === peopledata[i].lastName){
            var y = peopledata[i].zip
            break;
        }
        if(i===499){
            console.log(firstName+ " " + lastName +" not found") 
        }
    }
    for (j=0; j<499; j++){
        if(y === weatherdata[j].zip){
            if(weatherdata[j].temp>=34){
                console.log("Yes, "+ firstName+ " should go outside.")
                break;
            }
            else{
                console.log("No, "+ firstName+ " should not go outside.")
  
            }
        }
    }
} 
module.exports={
firstName:"Lalit",
lastName:"Kargutkar",
studendId: "10434413",
shouldTheyGoOutside};
