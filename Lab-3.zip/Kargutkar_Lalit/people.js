async function getPeople(){
    // const data=[];
    const axios=require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
    return data; // this will be the array of people
  }


  async function getPersonById(id){
  var peopledata=await getPeople();
      if (isNaN(id)){
         throw `${id} is not a number.`
      }


      else if(id<=0 || id>500){
        throw `${id} is out of bounds`;
      }

      else if (typeof id === 'undefined'){
        throw `${id} is undefined`
      }


      else{
        console.log(peopledata[id].firstName+" "+peopledata[id].lastName);
      }
  }




  async function lexIndex(index){
    const peopledata = await getPeople()
    
    function sortOn(property){
        return function(a, b){
            if(a[property] < b[property]){
                return -1;
            }else if(a[property] > b[property]){
                return 1;
            }else{
                return 0;   
            }
        }
    }
    if(typeof index === 'undefined' || typeof index !== "number" || !index){
        throw `${index} is not a number or undefined`;
    }
    else if(index <= 0 || index > 500){
        throw `${index} is out of bound`
    }
    else{
        peopledata.sort(sortOn('lastName'))
        console.log(peopledata[index].firstName+" "+peopledata[index].lastName)
        }
    }
   

  
    async function firstNameMetrics(){
      var x = []
      sum = 0;
      const peopledata = await getPeople()
      
      for(let i=0; i<500; i++){
         x.push(peopledata[i].firstName)
         sum += x[i].length
      }
      console.log("totalLetters:"+sum)
  
      
      let z = (""+x+"").split(/[aeiou]/i)
      let p = z.length-1
      console.log('Totalvowels:' +p )
      let y = (""+x+"").split(/[qwrtyplkjhgfdszxcvbnm]/i)
      let q= y.length-1;
      console.log("TotalConsonants"+q)
  
      let max = x.reduce((r, e) => r.length < e.length ? e : r, ""); // get name max length
      let min = x.reduce(function(a, b) {
          return a.length <= b.length ? a : b;
        })    // get name with minimum length
      console.log("longestName:"+max)
      console.log("shortestName:"+min)
  }


module.exports={
firstName:"Lalit",
lastName:"Kargutkar",
studendId: "10434413",
getPersonById,
lexIndex,
firstNameMetrics};