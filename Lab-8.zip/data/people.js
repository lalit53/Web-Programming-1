const axios = require('axios')
async function getPeople(){
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json')
    return data
  }

  async function getByID(id) {
    try{
      const peopledata = await getPeople()
      const people = []
      if((!id)) 
      {
        throw "ID not entered";
      }
      if(typeof id === 'number'){
        throw "ID should be number "
      }
      people.push(peopledata[id-1])
      return people
      }
    catch(err){
      return(err)
    }
  }

async function getByName(personName){
  const people = []
  let num = 20;
  const peopledata = await getPeople()
  if(!(personName)){
      throw "Please enter Name";
  }
  if(typeof personName !== "string"){
    throw "Name should be string"
  }
  for(i=0; i<500; i++){
    const name = peopledata[i].firstName.toLowerCase().indexOf(personName.toLowerCase()) !== -1 || peopledata[i].lastName.toLowerCase().indexOf(personName.toLowerCase()) !== -1;
    if(name && num > 0){
      people.push(peopledata[i])
      num--
    }  
  }
  return people;

  }

module.exports = {getByID, getByName};