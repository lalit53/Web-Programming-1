const searchRoutes = require("./people");

let constructorMethod = app => {
  app.use("/people", searchRoutes);
};

module.exports = {
  users: require("./people")
};