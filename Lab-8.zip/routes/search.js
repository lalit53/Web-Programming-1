const express = require("express");
const router = express.Router();
const peopleData = require("../data/people");

router.post("/", async (req, res) => {
  let body = req.body;
  let personName = body['name'];
  let hasErrors = false;
  let errors = [];

  if(personName.length === 0){
    hasErrors = true;
    errors.push("Enter Name");
    res.status(400);
    res.render("layouts/main", {hasErrors:hasErrors, errors: errors});
    return;
  }
  const people1 = await peopleData.getByName(personName);

  let renderData = {
    plist: people1,
    firstName: personName
  }
  res.render("users/madrid", renderData);
});

module.exports = router;