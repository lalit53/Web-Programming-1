const express = require("express");
const router = express.Router();
const peopleData = require("../data/people");

router.get("/:id", async (req, res) => {
  const id = await peopleData.getByID(req.params.id);
  res.render("users/real", { peopleID: id });
});

module.exports = router;