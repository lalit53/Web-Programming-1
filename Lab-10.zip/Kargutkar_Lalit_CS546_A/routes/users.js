const express = require("express");
const router = express.Router();
const users = require("../data/users");
const authenticate = require("../middleware/authenticate")

router.get("/", (req, res) => {
    if (req.cookies.name === 'AuthCookie') {
        res.redirect("/private")
    } else {
        res.render("users/home", { title: "Welcome" });
    }
});

router.get("/private", authenticate, (req, res, next) => {
    let user = req.session.user
    res.render("users/information",
        {
            user,
            title: `Hola ${user.firstName} ${user.lastName}`
        })
});

router.get("/logout", (req, res, next) => {
    res.clearCookie('name')
    res.redirect("/")
});

router.post("/login", (req, res, next) => {
    let uname = req.body.username;
    let pass = req.body.password
    let unameresult, passresult

    if (uname && pass) {
        unameresult = users.checkUsername(uname);
        passresult = users.matchPassword(uname, pass)

        if (unameresult && passresult.status) {
            let { _id, username, firstName, lastName, Profession, Bio } = passresult.user
            res.cookie('name', 'AuthCookie')
            let user = {
                _id,
                username,
                firstName,
                lastName,
                Profession,
                Bio
            }
            req.session.user = user
            res.redirect("/private")
        }
        else {
            res.render("users/home",
                {
                    title: "Login",
                    message: "Wrong username or password.",
                    status: false
                }
            )
        }
    }
    
    else {
        res.render("users/home",
            {
                title: "Login",
                message: "No username or password.",
                status: false
            }
        )
    }
});

module.exports = router;