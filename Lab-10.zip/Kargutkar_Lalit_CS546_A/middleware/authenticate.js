function authenticate(req, res, next) {
    if (req.cookies.name === 'AuthCookie') {
        next()
    } else {
        res.status(403).render("users/error", { title: "ERROR : 403 Forbidden" })
    }
}

module.exports = authenticate