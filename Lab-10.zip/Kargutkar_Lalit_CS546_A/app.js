const express = require("express");
const body = require("body-parser");
const cookie = require('cookie-parser');
const expssession = require('express-session')
const app = express();
const static = express.static(__dirname + "/public");
const Routes = require("./routes");
const x = require("express-handlebars");
const y = require("handlebars");

const Instance= x.create({
    defaultLayout: "main",
    helpers: {
        asJSON: (obj, spacing) => {
            if (typeof spacing === "number")
                return new y.SafeString(JSON.stringify(obj, null, spacing));
            return new y.SafeString(JSON.stringify(obj));
        }
    }
});

const rewriteUnsupportedBrowserMethods = (req, res, next) => {
    if (req.body && req.body._method) {
        req.method = req.body._method;
        delete req.body._method;
    }
    next();
};

app.use("/", static);
app.use(cookie());
app.use(body.json());
app.use(body.urlencoded({ extended: true }));
app.use(rewriteUnsupportedBrowserMethods);
app.use(expssession({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}))

app.engine("handlebars", Instance.engine);
app.set("view engine", "handlebars");

Routes(app);

app.listen(3000, () => {
    console.log("We've now got a server!");
    console.log("Your routes will be running on http://localhost:3000");
    if (process && process.send) process.send({ done: true });
});