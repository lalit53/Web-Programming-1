const users = require('./users')
    (function () {
        const Username = {
            checkUsername(uname) {
                if (uname.length === 0) throw "Provide valid username.";
                return users.users[uname];
            }
        };

        const Password = {
            matchPassword: (uname, pass) => {
                let user = users.users[uname];
                if (!user)
                    return {
                        status: false,
                        message: "No data."
                    };
                if (!bcrypt.compareSync(pass, user.hashedPassword))
                    return {
                        status: false,
                        message: "Wrong username /password."
                    };
                return {
                    status: true,
                    message: `${uname} ${pass}`
                };
            }
        };

        const staticForm = document.getElementById("login-form");


        if (staticForm) {
            const uname = document.getElementById("Username");
            const pass = document.getElementById("Password");

            const errorCon = document.getElementById("error-container");
            const errorText = errorCon.getElementsByClassName(
                "text-goes-here"
            )[0];

            const resultCon = document.getElementById("result-container");

            const resultText = resultCon.getElementsByClassName(
                "text-goes-here"
            )[0];

            staticForm.addEventListener("Submit", event => {
                event.preventDefault();

                try {
                    
                    errorCon.classList.add("hidden");
                    resultCon.classList.add("hidden");

                    let unamevalue = uname.value;
                    let passvalue = pass.value;

                    const unameresult = Username.checkUsername(
                        unamevalue
                    );

                    const passresult = Username.matchPassword(
                        passvalue
                    );

                    resultText.textContent = "The username is " + unameresult;
                    resultCon.classList.remove("hidden");

                } catch (e) {

                    const message = typeof e === "string" ? e : e.message;
                    errorText.textContent = e;
                    errorCon.classList.remove("hidden");
                }
            });
        }
    })();