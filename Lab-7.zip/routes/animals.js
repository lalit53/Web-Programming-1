const express = require('express');
const router = express.Router();
const animalData = require("../data/animals");

router.get("/", async (req,res) => {
    try{
        const p = await animalData.getAll()
        res.json(p)
    }
    catch(e){
        res.status(500).send();
    }
});

router.post("/", async (req, res) => {
    const blogAnimalData = req.body;
    
  
    if(!blogAnimalData || !blogAnimalData.name || !blogAnimalData.animalType || typeof blogAnimalData.name !== "string" || typeof blogAnimalData.animalType !== "string" ){
      res.status(400).json({ error: "Information not in proper format" })
      }
    try{
    const {name, animalType} = blogAnimalData
    const q = await animalData.create(name, animalType);
  
      res.json(q);
    } catch (e) {
      res.status(500).json({ error: e});
    }
  });

router.get("/:id", async (req,res) => {
    console.log(req.params)
      try{
          const r = await animalData.get(req.params.id)
          console.log(r)
          res.json(r)
      }
      catch(e){
          res.status(404).json({message:"Animal not found"});
      } 
  });

router.put("/:id", async (req, res) => {
  const animalInfo = req.body;                                       

  if (!animalInfo) {
    res.status(400).json({ error: "You must provide data to update a animal" });
    return;
  }

  try {
    await animalData.get(req.params.id);
  } catch (e) {
    res.status(404).json({ error: "No Animal" });
    return;
  }

  try {
    const updatedAnimal = await animalData.updateAnimal(req.params.id, animalInfo);
    res.json(updatedAnimal);
  } catch (e) {
    res.sendStatus(500).json({ error: e });
  }
});

router.delete("/:id", async (req, res) => {
    try {
      await animalData.get(req.params.id);
        } catch (e) {
      res.status(404).json({ error: "No Animal found" });
        }
    try {
          const s = await animalData.remove(req.params.id);
          res.json(s)
        } catch (e) {
          res.status(500).json({ error: e });
        }
      });

      module.exports=router;