const express = require("express");
const router = express.Router();
const postData = require("../data/posts");

router.get("/:id", async (req, res) => {
  console.log(req.params)
    try{
        const x = await postData.getPostById(req.params.id)
        console.log(x)
        res.json(x)
    }
    catch(e){
        res.status(404).json({message:"No Post found with given ID"});
    } 
});

router.get("/", async (req, res) => {
  try{
      const y = await postData.getAllPosts()
      res.json(y)
  }
  catch(e){
      res.status(500).send();
  }
});

router.post("/", async (req, res) =>{
  const blogPostData = req.body;
  

  if(!blogPostData || !blogPostData.title || !blogPostData.content || !blogPostData.authorID || typeof blogPostData.title !== "string" || typeof blogPostData.content !== "string"){
    res.status(400).json({ error: "Information not found or not in proper format" })
    }
  try{
  const {title, content, authorID} = blogPostData
  const z = await postData.addPost(title, content, authorID);

    res.json(z);
  } catch (e) {
    res.status(500).json({ error: e});
  }
});

router.put("/:id", async (req, res) =>  {
  const postInfo = req.body;                                       

  if (!postInfo) {
    res.status(400).json({ error: "ENter data" });
    return;
  }

  try {
    await postData.getPostById(req.params.id);
  } catch (e) {
    res.status(404).json({ error: "No Post found" });
    return;
  }

  try {
    const p = await postData.updatePost(req.params.id, postInfo);
    res.json(p);
  } catch (e) {
    res.sendStatus(500);
  }
  });

  router.delete("/:id", async (req, res) =>  {
    try {
      await postData.getPostById(req.params.id);
        } catch (e) {
      res.status(404).json({ error: "No Post found" });
        }
    try {
          const q = await postData.removePost(req.params.id);
          res.json(q)
        } catch (e) {
          res.status(500).json({ error: e });
        }
      });
  
  module.exports = router;