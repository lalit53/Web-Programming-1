const mongoCollections = require("./mongoCollections");
const animals = mongoCollections.animals;


  async function create(name, animalType){
    if(!name || !animalType){
        throw "Provide animalName or type"
    }

    const animalCollection = await animals();    
    let newAnimal = {
        name: name,
        animalType: animalType,
        likes: [],
        posts: []
    };
    return animalCollection
    .insertOne(newAnimal)
    .then(newInsertInformation => {
      return newInsertInformation.insertedId;
    })
    .then(newId => {
      return this.get(newId);
});
}

  async function getAll(){
    const animalCollection = await animals();
    const x = await animalCollection.find({}).toArray();

    return x;

}

  async function get(id){
    ObjectId = require('mongodb').ObjectID;
    if(!id){
        throw "Insert AnimalId"
    }
    const animalCollection = await animals();
    const y = await animalCollection.findOne({ _id: ObjectId(id) });
    if (y === null) throw "No animal with that id";

    return y;
}

  async function remove(id){
    const a = {};
    if(!id){ 
        throw "Enter ID";
        }
    
    const animalCollection = await animals();
    ObjectId = require('mongodb').ObjectID;
    const z = await get(id)
    const deletionInfo = await animalCollection.removeOne({ _id: ObjectId(id) });
    if (deletionInfo.deletedCount === 0) {
      throw `Could not delete animal with id of ${id}`;
        }

    a.deleted = true;
    a.data = z;
    return a;  

}

  async function updateAnimal(id, updatedAnimal) {
	  
	var ObjectId = require('mongodb').ObjectID;
	const animalCollection = await animals();

    const updatedAnimalData = {};

    if (updatedAnimal.name) {
      updatedAnimalData.name = updatedAnimal.name;
    }

    if (updatedAnimal.animalType) {
      updatedAnimalData.animalType = updatedAnimal.animalType;
    }

    let updateCommand = {
      $set: updatedAnimalData
    };
    const query = {
      _id: id
    };
    
	const updateInfo = await animalCollection.replaceOne({ _id: ObjectId(id) }, updateCommand);
	
	 if (updateInfo.modifiedCount === 0) {
      throw "Animal not succesfully updated";
    }

    return await this.get(id);  

        
    }

 

  module.exports={
    firstName: "Lalit", 
        lastName: "Kargutkar", 
        studentId: "10434413",
        create,
        get,
        getAll,
        remove,
        updateAnimal
}