const animalsData = require("./animals");
const postsData = require("./posts");

module.exports = {
  animals: animalsData,
  posts: postsData,
};