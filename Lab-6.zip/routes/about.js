const express=require("express");
const router = express.Router();

const abt = {
    name:"Lalit Kargutkar",
    cwid:"10434413",
    biography:"I am from Mumbai,India.\nI have completed my bachelors in Computer Engineering from University of Mumbai in May'18.\n I have enrolled in Stevens Institute of Technology to pursue Master in Computer Science.\n In my free time I like running and swimming. I am a state level swimmer and have run over a dozen marathons.",
    favouriteShows:["friends","office","top gear"],
    hoobbies:["swimming","running","gymming"]
}

router.get("/", async (req, res) => {
    try {
      
      res.json(abt);
    } catch (e) {
      res.status(500).send();
    }
  });

  
module.exports = router;