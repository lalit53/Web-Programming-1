const express = require ('express')
const router = express.Router()

const myschool=[
    {"schoolName":"St.Pius X High School",
     "degree":"High School",
     "favouriteClass":"Mathematics",
     "favouriteMemory":"Winning Athletic Events"
    },

    {"schoolName":"LTCOE",
     "degree":"Undergrad",
     "favouriteClass":"Web Programming Lab",
     "favouriteMemory":"writing Programs"

    },

    {"schoolName":"Stevens Institute of Technology",
    "degree":"Masters Degree",
    "favouriteClass":"Web Programming-I",
    "favouriteMemory":"Hackathon"
    }

]


router.get("/", async (req, res) => {
    try {
      
      res.json(myschool);
    } catch (e) {
      res.status(500).send();
    }
  });

module.exports=router;

