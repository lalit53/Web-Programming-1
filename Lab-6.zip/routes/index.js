

const education = require("./education");
const story = require("./story");
const about = require("./about");


const Method = app => {
  app.use("/education", education);
  app.use("/story", story);
   app.use("/about", about);
  
  app.use("*", (req, res) => {
    res.status(404).json({ error: "Not found" });
  });
};

module.exports = Method;
