const express = require("express");
const router = express.Router();

const mystory = {
    "storyTitle":"The story of Lalit",
    "story":"I was 6 years old. I was scared of water.\nI couldn't go near it. But my father couldn't see me like this. He enrolled me into swimming classes.I remember crying all night begging to get out of swimming classes. But my father was focused on removing the fear from my mind. I hated my father the day but at that time I didn't know what a wonderful hobby I was going to develop.\n On the first day of classes my coach was really friendly and kind. Even though I was cranky and irritating he was patient. He started teaching me the basics one step at a time. My coach neither let me go home, nor did he go home until I got it right. I owe it to my father and my coach that after years of their hardwork that I had overcome my fear of water and they were looking at a state level swimmer.  "
}


router.get("/", async (req, res) => {
    try {
      
      res.json(mystory);
    } catch (e) {
      res.status(500).send();
    }
  });

  
module.exports = router;