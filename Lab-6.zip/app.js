const express = require("express");
const application = express();
const configRoutes = require("./routes");

configRoutes(application);

application.listen(3000, () => {
  console.log("Server started!");
  console.log("Your routes will be running on http://localhost:3000");
});
