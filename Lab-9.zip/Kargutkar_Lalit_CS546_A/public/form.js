(function () {

    const primeChecker = document.getElementById("primeCheck");

    if (primeChecker) {

        primeChecker.addEventListener("submit", event => {
            event.preventDefault(); 
            const number = document.getElementById("number");
            let response = number.value;
            let initNumber=response;
            number.value="";

            if(response.length!=0){
                let error = document.getElementById("error");
                error.className = "error-Container-hidden";

                var count = 0;
 
                for (i = 1; i <= initNumber; i++) {
                    if (initNumber % i == 0) {
                        count = count + 1;
                    }
                }

                if (count==2) {
                    let list = document.createElement("li");
                    list.className = "prime";
                    let a = document.createTextNode(initNumber+" is a prime number");
                    list.appendChild(a);
                    let olist = document.getElementById("attempts");
                    olist.appendChild(list);
                }
                else {
                    let list = document.createElement("li");
                    list.className = "notprime";
                    let a = document.createTextNode(initNumber+" is NOT a prime number");
                    list.appendChild(a);
                    let olist = document.getElementById("attempts");
                    olist.appendChild(list);
                }
            }
            else{
                let error = document.getElementById("error");
                error.removeChild(error.childNodes[0]);
                error.className = "error";
                let node = document.createTextNode("No proper input in the input area");
                error.appendChild(node);
            }
            
        });
    }
})();