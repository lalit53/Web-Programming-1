extend=function(...args){
    if(args === "undefined"){
        throw `${args} is undefined`
    }

    else if (args.length<2){
        throw `${args} is less than 2`
    }

    else if(typeof args !== 'object'){
        throw  `${args} is not an object.`
    }
    else{
        return (args.reverse().reduce((x,y)=>({...x,...y}),{}))
    }
}

smush=function(...args){
    
    var temp= {};
    if(args === "undefined"){
        throw `${args} is undefined`
    }

    else if (args.length<2){
        throw `${args} is less than 2`
    }
    

    else{
    for(var i in args) {
        for(var j in args[i]){
            temp[j]=args[i][j];
        }
    }
    return (temp);
}
}






 module.exports={
     firstName:"Lalit",
     lastName:"Kargutkar",
     studendId: "10434413",
     extend,
     smush,

     };