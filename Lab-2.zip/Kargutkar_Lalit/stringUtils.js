capitalize=function(string){
    if(typeof string !== "string"){
        throw `${string} is not a string`;
    }

    else if (string === 'undefined'){
        throw `${string} is not of proper type`
    }

    else{
        var first=string.charAt(0).toUpperCase();
        var last=string.substr(1,string.length-1).toLowerCase();
        return(first+last);
       
    }
  
}

repeat=function(string,num){
    var i;
    if(typeof string !== "string"){
        throw `${string} is not a string`;
    }

    else if (string === 'undefined'){
        throw `${string} is not of proper type`
    }

    else if (num instanceof Number){
        throw `${end} is not a number`
    }
    else if (num<0){
        throw `${end} is negative`
    }

    else{
        return (string.repeat(num));
    }

}

countChars=function(string){
    var count={};
    if(typeof string !== "string"){
        throw `${string} is not a string`;
    }

    else if (string === 'undefined'){
        throw `${string} is not of proper type`
    }

    else{
        len = string.length;
    string = string.split('').reverse();
    while (len--) count[string[len]]=count[string[len]]+1 || 1;
    return (count);
    }

}

module.exports={
    firstName:"Lalit",
    lastName:"Kargutkar",
    studendId: "10434413",
    capitalize,
    repeat,
    countChars
};
