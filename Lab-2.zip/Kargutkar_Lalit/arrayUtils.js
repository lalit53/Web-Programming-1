head=function(array){
    if(typeof array === 'undefined'){
        throw `${array} is undefined`
    }
    else if(!(array instanceof Array)){
        throw `${array} is not an array`
    }

    else if(array.length === 0){
        throw `${array} is null`
    }

    else{
        return array[0];
    }
}


last=function(array){
    if(typeof array === 'undefined'){
        throw `${array} is undefined`
    }
    else if(!(array instanceof Array)){
        throw `${array} is not an array`
    }

    else if(array.length === 0){
        throw `${array} is null`
    }
    
    else{
        return(array[array.length-1]);
    }
}

remove=function(array,index){
    if(typeof array === 'undefined'){
        throw `${array} is undefined`
    }
    else if(!(array instanceof Array)){
        throw `${array} is not an array`
    }

    else if(array.length === 0){
        throw `${array} is null`
    }

    else if(index>array.length-1 || index<-1){
        throw `${array}is out of bounds`
    }

    else{

            array.splice(index,1);
            return (array);
        }
    }

range=function(end,value){
    var array=[];
    if (typeof end === 'undefined'){
        throw `${end} does not exist`
    }

    else if (end instanceof Number){
        throw `${end} is not a number`
    }
    else if (end<0){
        throw `${end} is negative`
    }
    else{
        var i;
     if (typeof value === 'undefined'){
        for(var i=0; i<=end-1; i++){
            array.push(i);
        }
    }

     else{
        
        for(i=0;i<end;i++){
          array.push(value);  
        }
       
    }
    return (array);
}
}

countElement=function(array){
    var count={};
    if(typeof array === 'undefined'){
        throw `${array} is undefined`
    }
    else if(!(array instanceof Array)){
        throw `${array} is not an array`
    }

    else{
        for(i=0;i<array.length;i++){
            count[array[i]]= 1+(count[array[i]] || 0);

        }
            return (count)
    }

}

isEqual=function(arrayOne,arrayTwo){
    if(typeof arrayOne === 'undefined') {
        throw `${arrayOne} is undefined or not an array or is empty`
    }
    else if(!(arrayOne instanceof Array)){
        throw `${arrayOne} is undefined or not an array or is empty`
    }

    else if(typeof arrayTwo === 'undefined') {
        throw `${arrayTwo} is undefined or not an array or is empty`
    }
    else if(!(arrayTwo instanceof Array)){
        throw `${arrayTwo} is undefined or not an array or is empty`
    }

    else{
        return (JSON.stringify(arrayOne)==JSON.stringify(arrayTwo))
    }
    
}

module.exports={
    firstName:"Lalit",
    lastName:"Kargutkar",
    studendId: "10434413",
    head,
    last,
    remove,
    range,
    countElement,
    isEqual
};



 




    
