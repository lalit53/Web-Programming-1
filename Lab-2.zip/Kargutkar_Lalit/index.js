const arrayUtils= require("./arrayUtils")
const stringUtils=require("./stringUtils")
const objUtils=require("./objUtils")

try {
    // Should Pass
    const headOne = head([2, 3, 4]);
    console.log(headOne);
    console.log('head passed successfully');
 } catch (e) {
    console.error('head failed test case');}

    try {
        // Should Pass
        const headTwo = head([5,6,7]);
        console.log(headTwo);
        console.log('head passed successfully');
     } catch (e) {
        console.error('head failed test case');}

try {
        // Should Pass
        const lastOne = last([1,2,3,4]);
        console.log(lastOne);
        console.log('last passed successfully');
 } catch (e) {
        console.error('last  failed test case');
    }

    try {
        // Should Pass
        const lasttwo = last([5,6,7,8]);
        console.log(lasttwo);
        console.log('last passed successfully');
 } catch (e) {
        console.error('last  failed test case');
    }

    try {
        // Should Pass
        const count1 = range(4,'hi');
        console.log(count1);
        console.log('last passed successfully');
 } catch (e) {
        console.error('last  failed test case');
    }


try {
    // Should Pass
    const capital = capitalize("FOOBAR");
    console.log(capital);
    console.log('capital passed successfully');
} catch (e) {
    console.error('capital failed test case')
}

try {
    // Should Pass
    const capital1 = capitalize("def");
    console.log(capital1);
    console.log('capital passed successfully');
} catch (e) {
    console.error('capital failed test case')
}

try {
    // Should Pass
    var h = extend({ x: 2, y: 3},{x:2,y:3,z:4})
    console.log(h);
    console.log('extend passed successfully');
} catch (e) {
    console.error('extend failed test case')
}







try {
    // Should Pass
    var h = smush({ x: 2, y: 3},{x:2,y:3,z:7})
    console.log(h);
    console.log('smush passed successfully');
} catch (e) {
    console.error('smush failed test case')
}

try {
    // Should Pass
    var h = smush({ x: 3, y: 5},{ a: 56, x: 45, z: 33},{ x: 6, y: 5, q: 10 })
    console.log(h);
    console.log('smush passed successfully');
} catch (e) {
    console.error('smush failed test case')
}












